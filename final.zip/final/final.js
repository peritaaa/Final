//escenario
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x33D7FF); 

var loader = new  THREE.TextureLoader();
loader.load(
    '../imagenes/fondo1.png', function(texture){
     scene.background = texture;
    }
);

//camara
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );

//render
const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
document.body.appendChild( renderer.domElement );

//geometria
const geometry = new THREE.TorusGeometry( 9, 4, 30, 40);
const material = new THREE.MeshStandardMaterial( { color: 0x4E5458 } );
const torus = new THREE.Mesh( geometry, material );
material.metalness = 0.3;
/* meterial1.envMap = evm; */
const directionalLight = new THREE.DirectionalLight(0x23272A, 5)
scene.add(directionalLight),
scene.add( torus )
camera.position.z = 24;
camera.position.x = 5;
camera.position.y = 10;

//Vaca1
const gltfLoader = new THREE.GLTFLoader();

gltfLoader.load('../vaca_2/scene.gltf', 
(gltf) =>{
    var loaderObjeto = gltf.scene;
    loaderObjeto.scale.set(0.2,0.2,0.2)
    console.log('carga completa');
    scene.add(loaderObjeto);
    const directionalLight2 = new THREE.AmbientLight(0xFFFFFF)
    scene.add(directionalLight2)
    loaderObjeto.position.x = -22
    loaderObjeto.position.y = 20
    loaderObjeto.position.Z = 2
    const controls1 = new THREE.DragControls( [loaderObjeto], camera, renderer.domElement );
    
    
}, ()=>{
    console.log('cargando');
}, ()=>{
    console.log('error')
}
);

//Vaca2
const gltfLoader3 = new THREE.GLTFLoader();

gltfLoader.load('../vaca_2/scene.gltf', 
(gltf) =>{
    var loaderObjeto3 = gltf.scene;
    loaderObjeto3.scale.set(0.1,0.1,0.1)
    console.log('carga completa');
    scene.add(loaderObjeto3);
    loaderObjeto3.position.x = 14
    loaderObjeto3.position.y = 19
    loaderObjeto3.position.z = 0
    const controls2 = new THREE.DragControls( [loaderObjeto3], camera, renderer.domElement );
    const directionalLight3 = new THREE.AmbientLight3(0xFFFFFF)
    scene.add(directionalLight3)
    
    
}, ()=>{
    console.log('cargando');
}, ()=>{
    console.log('error')
}
);

//Line
const edges = new THREE.EdgesGeometry( geometry );
const line = new THREE.LineSegments( edges, new THREE.LineBasicMaterial( { color: 0xFFFFFF } ) );
scene.add( line );

//animacion
function animate() {
    requestAnimationFrame( animate );
    torus.rotation.z += 0.02
    renderer.render( scene, camera );
}
animate();